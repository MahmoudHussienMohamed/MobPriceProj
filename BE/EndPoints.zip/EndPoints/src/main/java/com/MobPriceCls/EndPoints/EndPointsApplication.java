package com.MobPriceCls.EndPoints;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndPointsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndPointsApplication.class, args);
	}

}
